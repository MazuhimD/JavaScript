//variaveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 20;
let raio = diametro / 2

//velocidade da bolinha
let velocidadeXBolinha = 5;
let velocidadeYBolinha = 5;

//variaveis da minha raquete
let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 80;
let colidiu = false;

//variaveis do oponente
let xRaqueteO = 580;
let yRaqueteO = 150;
let raqueteOComprimento = 10;
let raqueteOAltura = 80;
let velocidadeYO;
let chanceDeErrar = 0;

//placar do jogo
let meusPontos = 0;
let pontosOponente = 0;

//sons do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  verificaColisaoRaquete();
  mostraRaquete(xRaqueteO, yRaqueteO);
  movimentaRaqueteO();
  verificaColisaoRaqueteO();
  incluiPlacar();
  marcaPonto();

  

function mostraBolinha(){
   circle(xBolinha, yBolinha, diametro)
}

function movimentaBolinha(){
    xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda(){
  
  
  if (xBolinha + raio > width || 
     xBolinha - raio < 0){
    velocidadeXBolinha *= -1;
  }
  
  if (yBolinha + raio > height ||
     yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
  }
}
  
  function mostraRaquete(x, y){
      rect(x, y, raqueteComprimento, raqueteAltura);
  }
  
  
  function movimentaMinhaRaquete(){
    if (keyIsDown(UP_ARROW))
  yRaquete -= 10;
    
    if (keyIsDown (DOWN_ARROW))
      yRaquete += 10;
  }
  
  
  function verificaColisaoRaquete(){
    if (xBolinha - raio < xRaquete + raqueteComprimento && yBolinha - raio < yRaquete + raqueteAltura && yBolinha + raio > yRaquete){
    velocidadeXBolinha *= -1 
      raquetada.play();
    }
    
  }
  
  function movimentaRaqueteO(){
  velocidadeYO = yBolinha -yRaqueteO - raqueteOComprimento / 2 - 30;
  yRaqueteO += velocidadeYO + chanceDeErrar
  calculaChanceDeErrar()
}
 

  function calculaChanceDeErrar() {
  if (pontosOponente >= meusPontos) {
    chanceDeErrar += 1
    if (chanceDeErrar >= 39){
    chanceDeErrar = 38
    }
  } else {
    chanceDeErrar -= 1
    if (chanceDeErrar <= 35){
    chanceDeErrar = 35
    }
  }
}
    function verificaColisaoRaqueteO(){
    if (xBolinha + raio > xRaqueteO && yBolinha - raio < yRaqueteO + raqueteOAltura && yBolinha + raio > yRaqueteO){
      velocidadeXBolinha *= -1;
      raquetada.play();
    }      
     
  }
  
  function incluiPlacar(){
    stroke(255);
    textAlign(CENTER);
    textSize(30);
    fill(color(255,140,0))
    rect(150, 10, 60, 40);
    fill (255);
    text(meusPontos, 180, 40);
    fill(color(255,140,0))
    rect(380, 10, 60, 40);
    fill (255);
    text(pontosOponente, 410, 40);
  }
  
  function marcaPonto(){
    if (xBolinha < 10){
      pontosOponente += 1; 
      ponto.play();
    }
    
    if (xBolinha > 590){
      meusPontos += 1;
      ponto.play();
    }
  }
}

